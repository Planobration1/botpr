<?php
$statItems = [
['stat' => $stats->base_price, 'label' => __('Base Pair Price at Last Trade')],
['stat' => $stats->trading_pair_price, 'label' => __('Trading Pair Price')],
];
?>

<!-- Stats -->
<div class="space-y-6">
    <?php $__currentLoopData = $statItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white dark:bg-gray-800 rounded-lg p-4 md:p-6">
        <h3 class="text-2xl md:text-4xl mb-1"><?php echo e($item['stat']); ?></h3>
        <p class="text-sm"><?php echo e($item['label']); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/platinum/Documents/App/Freelance/xbot/resources/views/dashboard/partials/stats.blade.php ENDPATH**/ ?>