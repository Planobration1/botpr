<footer class="my-12 space-y-2 text-xs text-center">
    Copyright &copy; {{date('Y')}} &bullet; Built by <a href="http://emmanuel.mantenar.com" target="_blank" rel="noopener noreferrer" class="underline">Emmanuel Adesina</a>
</footer>
