<x-app-layout>
    <h6 class="font-bold text-lg">Logged Fails</h6>
    <livewire:log-table />
</x-app-layout>
