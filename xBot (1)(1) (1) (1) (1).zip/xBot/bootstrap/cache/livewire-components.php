<?php return array (
  'log-table' => 'App\\Http\\Livewire\\LogTable',
  'trade-table' => 'App\\Http\\Livewire\\TradeTable',
);